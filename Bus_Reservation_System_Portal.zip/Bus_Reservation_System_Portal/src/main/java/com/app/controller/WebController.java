package com.busbooking.busapp.controller;

import com.busbooking.busapp.model.Bus;
import com.busbooking.busapp.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class WebController {

    @Autowired
    private BusRepository busRepository;

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/search")
    public String searchPage() {
        return "search";
    }

    @GetMapping("/buses/search")
    public String searchBuses(@RequestParam String source,
                              @RequestParam String destination,
                              Model model) {
        List<Bus> buses = busRepository.findBySourceAndDestination(source, destination);
        model.addAttribute("buses", buses);
        return "results";
    }

    @GetMapping("/book/{busId}")
    public String bookPage(@PathVariable Long busId, Model model) {
        Bus bus = busRepository.findById(busId).orElse(null);
        model.addAttribute("bus", bus);
        return "book";
    }

    @PostMapping("/reservations")
    public String confirmBooking(@RequestParam Long busId,
                                 @RequestParam String name,
                                 @RequestParam String email,
                                 Model model) {
        // You can save to database here if Reservation entity exists
        model.addAttribute("name", name);
        return "success";
    }
}
