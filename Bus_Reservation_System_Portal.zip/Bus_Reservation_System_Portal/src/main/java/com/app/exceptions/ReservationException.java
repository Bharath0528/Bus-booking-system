package com.app.exceptions;

public class ReservationException extends Exception {

	public ReservationException() {
		// TODO Auto-generated constructor stub
	}
	
	public ReservationException(String message) {
		// TODO Auto-generated constructor stub
	
		super(message);
	}
}
