package com.app.exceptions;

public class LoginException extends Exception{
	
	public LoginException() {
		// TODO Auto-generated constructor stub
	}
	
	public LoginException(String mssg) {
		
		super(mssg);
		// TODO Auto-generated constructor stub
	}

}
